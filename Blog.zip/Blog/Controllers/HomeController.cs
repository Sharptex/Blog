﻿using Blog.ViewModels;
using Blog.ViewModels.Account;
using Blog_DAL.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Blog.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : Controller
    {
        private readonly SignInManager<User> _signInManager;

        public HomeController(SignInManager<User> signInManager)
        {
            _signInManager = signInManager;
        }

        [Route("")]
        [Route("[controller]/[action]")]
        [HttpGet]
        public IActionResult Index()
        {
            if (_signInManager.IsSignedIn(User))
            {
                //return View("Index");
                return Ok(new MainViewModel());
            }
            else
            {
                //return View(new MainViewModel());
                return Ok(new MainViewModel());
            }
        }

        [Route("[action]")]
        [HttpGet]
        public IActionResult Privacy()
        {
            return View();
        }

        [Route("error/404")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        [HttpGet]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
